---
permalink: /docs/deploying/
---

# Deploying

- [Azure](./deploying/azure.md)
- [Bluemix](./deploying/bluemix.md)
- [Heroku](./deploying/heroku.md)
- [Unix](./deploying/unix.md)
- [Windows](./deploying/windows.md)
